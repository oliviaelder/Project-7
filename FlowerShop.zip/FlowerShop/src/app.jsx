// src/App.jsx
import React from 'react';

function App() {
  return (
    <div>
      <h1>Welcome to Liv's Flower Bouquets</h1>
      <p>Explore our collection of beautiful bouquets!</p>
    </div>
  );
}

export default App;
