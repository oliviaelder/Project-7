import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: '/Project-7/',  // Ensure this is set correctly for your GitHub Pages deployment
  plugins: [react()],
});
